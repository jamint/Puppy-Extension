if(navigator.onLine) { // true|false
	console.log("I'm online....");
} else {
	console.log("I'm offline...");
}